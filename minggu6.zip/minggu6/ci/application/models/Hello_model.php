<?php
	class Hello_model extends CI_Model{
		//membuat properti dengan nama var $txt
		public $txt = 'Hello World!';
	}
?>
