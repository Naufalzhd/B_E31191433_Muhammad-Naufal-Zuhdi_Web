<?php
	class soal1_model extends CI_Model{
		public $txt = 'Hello Wolrd dari CI Model';
	}
?>
