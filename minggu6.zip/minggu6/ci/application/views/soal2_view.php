<html>
<head>
	<title>Soal</title>
</head>
<body>
	menampilkan lebih dari 1 variabel menggunakan Controller, Model dan View
	<br></br>
	variabel 1: <?php echo $dataku['data1']; ?><br>
	variabel 2: <?php echo $dataku['data2']; ?><br>
	variabel 3: <?php echo $dataku['data3']; ?><br>
	variabel 4: <?php echo $dataku['data4']; ?><br>
</body>
</html>
