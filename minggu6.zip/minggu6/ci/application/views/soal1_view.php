<html>
<head>
	<title>Soal</title>
</head>
<body>
	<h1><?php echo $teks; ?></h1>
</body>
</html>
